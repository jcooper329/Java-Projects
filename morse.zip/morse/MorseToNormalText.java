import java.util.Scanner;
/**
 * Write a description of class MorseToNormalText here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MorseToNormalText
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter a Morse Code:");
        String morseCode = scanner.nextLine();
        
        System.out.println("\nNormal Text:");
        String text = MorseCodeToText.getText(morseCode);
        System.out.println(text);
    }
}
