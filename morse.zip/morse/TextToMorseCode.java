
/**
 * Write a description of class TextToMorseCode here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TextToMorseCode
{
    private static final String[] numbers = {"-----", "----.", ".----", "..---", "...--", "....-", ".....", "-....", "--...", "---.." };
        
    private static final String[] letters = {".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", 
        ".---", "-.-", ".-..", "--", "-.", "---", ".---.", "--.-", ".-.",
        "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..", "--..--", ".-.-.-", "..--.."};
        
    public static String getMorseCode(String phrase)
    {
        String morseCode = "";
        
        for (int i = 0; i < phrase.length(); i++)
        {
            char alpha = phrase.charAt(i);
            
            if (Character.isDigit(alpha))
            {
                morseCode += numbers[alpha - '0'] + " ";
            }
            
            if (Character.isLetter(alpha))
            {
                morseCode +=
                    letters[Character.toUpperCase(alpha) - 'A'] + " ";
            }
            
            if (alpha == ' ')
            {
                morseCode += "   ";
            }
        }
        
        return morseCode;
    }
}
