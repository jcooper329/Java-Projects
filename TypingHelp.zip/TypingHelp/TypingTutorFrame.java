import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;

public class TypingTutorFrame extends JFrame
{
    private JLabel prompt1JLabel, prompt2JLabel;
    private JTextArea outputJTextArea;

    private JButton tildeJButton, oneJButton, twoJButton, threeJButton, fourJButton, fiveJButton, sixJButton,
    sevenJButton, eightJButton, nineJButton, zeroJButton, hyphenJButton, plusJButton, backspaceJButton;

    private JButton tabJButton, qJButton, wJButton, eJButton, rJButton, tJButton, yJButton, uJButton, iJButton, 
    oJButton, pJButton, leftBraceJButton, rightBraceJButton, slashJButton;

    private JButton capsJButton, aJButton, sJButton, dJButton, fJButton, gJButton, hJButton, jJButton, kJButton, 
    lJButton, colonJButton, quoteJButton, enterJButton;

    private JButton shiftLeftJButton, zJButton, xJButton, cJButton, vJButton, bJButton, nJButton, mJButton, commaJButton, 
    periodJButton, questionJButton, upJButton;

    private JButton spaceJButton, leftJButton, downJButton, rightJButton;

    private JButton lastJButton;

    private JButton[] keyJButton = new JButton[KeyEvent.KEY_LAST + 1];

    public TypingTutorFrame()
    {
        super("Typing Tutor");
        setLayout(null);

        prompt1JLabel = new JLabel("Type some text using your keyboard");
        prompt1JLabel.setBounds(15, 5, 725, 20);
        add(prompt1JLabel);

        prompt2JLabel = new JLabel("Note: Dont click the buttons");
        prompt2JLabel.setBounds(15, 20, 725, 25);
        add(prompt1JLabel);

        outputJTextArea = new JTextArea();
        outputJTextArea.setBounds(15, 50, 725, 175);
        outputJTextArea.setLineWrap(true);
        add(outputJTextArea);
        outputJTextArea.addKeyListener(
            new KeyListener()
            {
                public void keyPressed(KeyEvent event)
                {
                    int buttonIndex = event.getKeyCode();
                    changeColor(keyJButton[buttonIndex]);
                }

                public void keyReleased(KeyEvent event)
                {
                    resetColor();   
                }

                public void keyTyped(KeyEvent event)
                {
                    //nothing
                }
            }
        );

        outputJTextArea.addFocusListener(
            new FocusAdapter()
            {
                public void focusLost(FocusEvent event)
                {
                    resetColor();  
                }
            }
        );

        createButtons();
    }

    private void createButtons()
    {
        tildeJButton = new JButton("~");
        tildeJButton.setBounds(15, 250, 48, 48);
        add(tildeJButton);
        keyJButton[KeyEvent.VK_BACK_QUOTE] = tildeJButton;

        oneJButton = new JButton("1");
        oneJButton.setBounds(63, 250, 48, 48);
        add(oneJButton);
        keyJButton[KeyEvent.VK_1] = oneJButton;

        twoJButton = new JButton("2");
        twoJButton.setBounds(111, 250, 48, 48);
        add(twoJButton);
        keyJButton[KeyEvent.VK_2] = twoJButton;

        threeJButton = new JButton("3");
        threeJButton.setBounds(159, 250, 48, 48);
        add(threeJButton);
        keyJButton[KeyEvent.VK_3] = threeJButton;

        fourJButton = new JButton("4");
        fourJButton.setBounds(207, 250, 48, 48);
        add(fourJButton);
        keyJButton[KeyEvent.VK_4] = fourJButton;

        fiveJButton = new JButton("5");
        fiveJButton.setBounds(255, 250, 48, 48);
        add(fiveJButton);
        keyJButton[KeyEvent.VK_5] = fiveJButton;

        sixJButton = new JButton("6");
        sixJButton.setBounds(303, 250, 48, 48);
        add(sixJButton);
        keyJButton[KeyEvent.VK_6] = sixJButton;

        sevenJButton = new JButton("7");
        sevenJButton.setBounds(352, 250, 48, 48);
        add(sevenJButton);
        keyJButton[KeyEvent.VK_7] = sevenJButton;

        eightJButton = new JButton("8");
        eightJButton.setBounds(399, 250, 48, 48);
        add(eightJButton);
        keyJButton[KeyEvent.VK_8] = eightJButton;

        nineJButton = new JButton("9");
        nineJButton.setBounds(447, 250, 48, 48);
        add(nineJButton);
        keyJButton[KeyEvent.VK_9] = nineJButton;

        zeroJButton = new JButton("0");
        zeroJButton.setBounds(495, 250, 48, 48);
        add(zeroJButton);
        keyJButton[KeyEvent.VK_0] = zeroJButton;

        hyphenJButton = new JButton("-");
        hyphenJButton.setBounds(543, 250, 48, 48);
        add(hyphenJButton);
        keyJButton[KeyEvent.VK_MINUS] = hyphenJButton;

        plusJButton = new JButton("+");
        plusJButton.setBounds(591, 250, 48, 48);
        add(plusJButton);
        keyJButton[KeyEvent.VK_EQUALS] = plusJButton;

        backspaceJButton = new JButton("Backspace");
        backspaceJButton.setBounds(639, 250, 100, 48);
        add(backspaceJButton);
        keyJButton[KeyEvent.VK_BACK_SPACE] = backspaceJButton;

        tabJButton = new JButton("Tab");
        tabJButton.setBounds(15, 298, 60, 48);
        add(tabJButton);
        keyJButton[KeyEvent.VK_TAB] = tabJButton;

        qJButton = new JButton("Q");
        qJButton.setBounds(63, 298, 48, 48);
        add(qJButton);
        keyJButton[KeyEvent.VK_Q] = qJButton;

        wJButton = new JButton("W");
        wJButton.setBounds(111, 298, 48, 48);
        add(wJButton);
        keyJButton[KeyEvent.VK_W] = wJButton;

        eJButton = new JButton("E");
        eJButton.setBounds(159, 298, 48, 48);
        add(eJButton);
        keyJButton[KeyEvent.VK_E] = eJButton;

        rJButton = new JButton("R");
        rJButton.setBounds(207, 298, 48, 48);
        add(rJButton);
        keyJButton[KeyEvent.VK_R] = rJButton;

        tJButton = new JButton("T");
        tJButton.setBounds(255, 298, 48, 48);
        add(tJButton);
        keyJButton[KeyEvent.VK_T] = tJButton;

        yJButton = new JButton("Y");
        yJButton.setBounds(303, 298, 48, 48);
        add(yJButton);
        keyJButton[KeyEvent.VK_Y] = yJButton;

        uJButton = new JButton("U");
        uJButton.setBounds(352, 298, 48, 48);
        add(uJButton);
        keyJButton[KeyEvent.VK_U] = uJButton;

        iJButton = new JButton("I");
        iJButton.setBounds(399, 298, 48, 48);
        add(iJButton);
        keyJButton[KeyEvent.VK_I] = iJButton;

        oJButton = new JButton("O");
        oJButton.setBounds(447, 298, 48, 48);
        add(oJButton);
        keyJButton[KeyEvent.VK_O] = oJButton;

        pJButton = new JButton("P");
        pJButton.setBounds(495, 298, 48, 48);
        add(pJButton);
        keyJButton[KeyEvent.VK_P] = pJButton;

        leftBraceJButton = new JButton("{");
        leftBraceJButton.setBounds(543, 298, 48, 48);
        add(leftBraceJButton);
        keyJButton[KeyEvent.VK_OPEN_BRACKET] = leftBraceJButton;

        rightBraceJButton = new JButton("}");
        rightBraceJButton.setBounds(591, 298, 48, 48);
        add(rightBraceJButton);
        keyJButton[KeyEvent.VK_CLOSE_BRACKET] = rightBraceJButton;

        slashJButton = new JButton("\\");
        slashJButton.setBounds(639, 298, 48, 48);
        add(slashJButton);
        keyJButton[KeyEvent.VK_BACK_SLASH] = slashJButton;

        // set up capsJButton
        capsJButton = new JButton("Caps");
        capsJButton.setBounds(15, 346, 75, 48);
        add(capsJButton);
        keyJButton[KeyEvent.VK_CAPS_LOCK] = capsJButton;

        // set up aJButton
        aJButton = new JButton("A");
        aJButton.setBounds(90, 346, 48, 48);
        add(aJButton);
        keyJButton[KeyEvent.VK_A] = aJButton;

        // set up sJButton
        sJButton = new JButton("S");
        sJButton.setBounds(138, 346, 48, 48);
        add(sJButton);
        keyJButton[KeyEvent.VK_S] = sJButton;

        // set up dJButton
        dJButton = new JButton("D");
        dJButton.setBounds(186, 346, 48, 48);
        add(dJButton);
        keyJButton[KeyEvent.VK_D] = dJButton;

        // set up fJButton
        fJButton = new JButton("F");
        fJButton.setBounds(234, 346, 48, 48);
        add(fJButton);
        keyJButton[KeyEvent.VK_F] = fJButton;

        // set up gJButton
        gJButton = new JButton("G");
        gJButton.setBounds(282, 346, 48, 48);
        add(gJButton);
        keyJButton[KeyEvent.VK_G] = gJButton;

        // set up hJButton
        hJButton = new JButton("H");
        hJButton.setBounds(330, 346, 48, 48);
        add(hJButton);
        keyJButton[KeyEvent.VK_H] = hJButton;

        // set up jJButton
        jJButton = new JButton("J");
        jJButton.setBounds(378, 346, 48, 48);
        add(jJButton);
        keyJButton[KeyEvent.VK_J] = jJButton;

        // set up kJButton
        kJButton = new JButton("K");
        kJButton.setBounds(426, 346, 48, 48);
        add(kJButton);
        keyJButton[KeyEvent.VK_K] = kJButton;

        // set up lJButton
        lJButton = new JButton("L");
        lJButton.setBounds(474, 346, 48, 48);
        add(lJButton);
        keyJButton[KeyEvent.VK_L] = lJButton;

        // set up colonJButton
        colonJButton = new JButton(":");
        colonJButton.setBounds(522, 346, 48, 48);
        add(colonJButton);
        keyJButton[KeyEvent.VK_SEMICOLON] = colonJButton;

        // set up quoteJButton
        quoteJButton = new JButton("\"");
        quoteJButton.setBounds(570, 346, 48, 48);
        add(quoteJButton);
        keyJButton[KeyEvent.VK_QUOTE] = quoteJButton;

        // set up enterJButton
        enterJButton = new JButton("Enter");
        enterJButton.setBounds(618, 346, 96, 48);
        add(enterJButton);
        keyJButton[KeyEvent.VK_ENTER] = enterJButton;

        // set up shiftLeftJButton
        shiftLeftJButton = new JButton("Shift");
        shiftLeftJButton.setBounds(15, 394, 100, 48);
        add(shiftLeftJButton);
        keyJButton[KeyEvent.VK_SHIFT] = shiftLeftJButton;

        // set up zJButton
        zJButton = new JButton("Z");
        zJButton.setBounds(115, 394, 48, 48);
        add(zJButton);
        keyJButton[KeyEvent.VK_Z] = zJButton;

        // set up xJButton
        xJButton = new JButton("X");
        xJButton.setBounds(163, 394, 48, 48);
        add(xJButton);
        keyJButton[KeyEvent.VK_X] = xJButton;

        // set up cJButton
        cJButton = new JButton("C");
        cJButton.setBounds(211, 394, 48, 48);
        add(cJButton);
        keyJButton[KeyEvent.VK_C] = cJButton;

        // set up vJButton
        vJButton = new JButton("V");
        vJButton.setBounds(259, 394, 48, 48);
        add(vJButton);
        keyJButton[KeyEvent.VK_V] = vJButton;

        // set up bJButton
        bJButton = new JButton("B");
        bJButton.setBounds(307, 394, 48, 48);
        add(bJButton);
        keyJButton[KeyEvent.VK_B] = bJButton;

        // set up nJButton
        nJButton = new JButton("N");
        nJButton.setBounds(355, 394, 48, 48);
        add(nJButton);
        keyJButton[KeyEvent.VK_N] = nJButton;

        // set up mJButton
        mJButton = new JButton("M");
        mJButton.setBounds(403, 394, 48, 48);
        add(mJButton);
        keyJButton[KeyEvent.VK_M] = mJButton;

        // set up commaJButton
        commaJButton = new JButton(",");
        commaJButton.setBounds(451, 394, 48, 48);
        add(commaJButton);
        keyJButton[KeyEvent.VK_COMMA] = commaJButton;

        // set up periodJButton
        periodJButton = new JButton(".");
        periodJButton.setBounds(499, 394, 48, 48);
        add(periodJButton);
        keyJButton[KeyEvent.VK_PERIOD] = periodJButton;

        // set up questionJButton
        questionJButton = new JButton("?");
        questionJButton.setBounds(547, 394, 48, 48);
        add(questionJButton);
        keyJButton[KeyEvent.VK_SLASH] = questionJButton;

        // set up upJButton
        upJButton = new JButton("^");
        upJButton.setBounds(618, 394, 48, 48);
        add(upJButton);
        keyJButton[KeyEvent.VK_UP] = upJButton;

        // set up spaceJButton
        spaceJButton = new JButton("");
        spaceJButton.setBounds(208, 442, 300, 48);
        add(spaceJButton);
        keyJButton[KeyEvent.VK_SPACE] = spaceJButton;

        // set up leftJButton
        leftJButton = new JButton("<");
        leftJButton.setBounds(570, 442, 48, 48);
        add(leftJButton);
        keyJButton[KeyEvent.VK_LEFT] = leftJButton;

        // set up downJButton
        downJButton = new JButton("v");
        downJButton.setBounds(618, 442, 48, 48);
        add(downJButton);
        keyJButton[KeyEvent.VK_DOWN] = downJButton;

        // set up rightJButton
        rightJButton = new JButton(">");
        rightJButton.setBounds(666, 442, 48, 48);
        add(rightJButton);
        keyJButton[KeyEvent.VK_RIGHT] = rightJButton;

    }
    private void changeColor(JButton changeJButton)
   {
      if (changeJButton != null)
      {
         resetColor();
         changeJButton.setBackground(Color.PINK);
         lastJButton = changeJButton;
      }
   } 

   // changes lastJButton's color back to default
   private void resetColor()
   {
      if (lastJButton != null)
         lastJButton.setBackground(this.getBackground());
   } 

}