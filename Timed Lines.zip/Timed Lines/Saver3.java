import javax.swing.JFrame;

public class Saver3
{
    public static void main(String args[])
    {
        JFrame frame = new JFrame("Screen Saver Sample");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        SaverJPanel saverJPanel= new SaverJPanel();
        frame.add(saverJPanel);
        frame.setSize(400, 400);
        frame.setVisible(true);
    }
}