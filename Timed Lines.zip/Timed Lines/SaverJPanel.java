import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.util.Random;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;
public class SaverJPanel extends JPanel implements ActionListener
{
    private static final Random random = new Random();
    
    private Timer timer;
    private int numberLines;
    
    private JTextField input;
    
    public SaverJPanel()
    {
        numberLines = 100;
        timer = new Timer(100,this);
        timer.start();
        
        input = new JTextField(10);
        input.addActionListener(
            new ActionListener()
            {
                public void actionPerformed(ActionEvent event)
                {
                    numberLines = Integer.parseInt(input.getText());
                }
            }
        );
        setLayout(new FlowLayout());
        add(input);
    }
    
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        int x, y, x1, y1;
        
        for (int i = 0; i < numberLines; i++)
        {
            x = random.nextInt(300);
            y = random.nextInt(300);
            x1 = random.nextInt(300);
            y1 = random.nextInt(300);
            
            g.setColor(new Color(random.nextFloat(), random.nextFloat(), random.nextFloat()));
            g.drawLine(x,y,x1,y1);
        }
    }
    
    public void actionPerformed(ActionEvent actionEvent)
    {
        repaint();
    }
}